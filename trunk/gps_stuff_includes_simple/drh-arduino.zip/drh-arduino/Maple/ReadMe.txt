The Maple IDE is only available for 32-bit. To make it work on 64-bit 
the following two files need to copied to the lib subdirectory of the 
Maple installation; e.g., /home/rainer/Downloads/maple-ide-v0.0.12/lib

More info: http://forums.leaflabs.com/topic.php?id=1100


/home/rainer/dev/drh-robotics-ros/Maple/Setup/librxtxSerial.so
/home/rainer/dev/drh-robotics-ros/Maple/Setup/RXTXcomm.jar
